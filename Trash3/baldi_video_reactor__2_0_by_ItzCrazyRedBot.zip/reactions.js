import { ImprovedAIReactions } from './improved-ai-reactions.js';
import { SpeechBubble } from './speech-bubble.js';
import { DetentionManager } from './detention-manager.js';
import { AIReactions } from './ai-reactions.js';

const speechBubble = new SpeechBubble();
const detentionManager = new DetentionManager();
let isAnalyzing = false; // Add a flag to prevent concurrent analysis

export async function captureAndAnalyzeFrame(video) {
    try {
        // Don't do anything if detention is active or another analysis is in progress.
        if (detentionManager.isDetentionActive || isAnalyzing) return;

        // Ensure video has dimensions before creating canvas
        if (!video.videoWidth || !video.videoHeight) return;

        isAnalyzing = true; // Set the flag

        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');

        // First, check for inappropriate content.
        const safetyCheck = await AIReactions.checkVideoContent(dataUrl);

        if (safetyCheck && safetyCheck.detentionRequired) {
            // If content is inappropriate, trigger detention and stop.
            detentionManager.triggerDetention(video, safetyCheck.detentionMessage);
            isAnalyzing = false; // Reset the flag
            return; 
        }

        // Get Baldi's reaction using improved AI
        const reaction = await ImprovedAIReactions.generateVideoReaction(dataUrl);
        speechBubble.show(reaction.message, reaction.emotion);

        // Log the reaction if logManager exists
        if (window.logManager) {
            window.logManager.addLog(window.logManager.logTypes.BALDI_REACTION, reaction.message, {
                emotion: reaction.emotion,
                source: video.id === 'screenShareVideo' ? 'screen-share' : 'video'
            });
        }

    } catch (error) {
        console.error('Error during frame analysis:', error);
        speechBubble.show("Let's solve this! :quarter:", "excited");
        
        // Log the error if logManager exists
        if (window.logManager) {
            window.logManager.addLog(window.logManager.logTypes.BALDI_REACTION, "Error analyzing video frame: Let's solve this! :quarter:", {
                error: error.message,
                source: video.id === 'screenShareVideo' ? 'screen-share' : 'video'
            });
        }
    } finally {
        isAnalyzing = false; // Always reset the flag
    }
}

export async function handlePhotoUpload(file) {
    const photoDisplay = document.createElement('img');
    photoDisplay.id = 'photoDisplay';
    photoDisplay.style.maxWidth = '100%';
    photoDisplay.style.maxHeight = '600px';
    document.querySelector('.video-section').appendChild(photoDisplay);

    const reader = new FileReader();
    reader.onload = (e) => {
        photoDisplay.src = e.target.result;
        
        // Log the photo upload if logManager exists
        if (window.logManager) {
            window.logManager.addLog(window.logManager.logTypes.FILE_SELECTION, `Uploaded photo: ${file.name}`, {
                fileType: file.type,
                fileSize: `${(file.size / (1024 * 1024)).toFixed(2)} MB`
            });
        }
    };
    reader.readAsDataURL(file);
}

export async function analyzePhoto(dataUrl) {
    try {
        const reaction = await ImprovedAIReactions.generateVideoReaction(dataUrl);
        speechBubble.show(reaction.message, reaction.emotion);
        
        // Log the photo reaction if logManager exists
        if (window.logManager) {
            window.logManager.addLog(window.logManager.logTypes.BALDI_REACTION, reaction.message, {
                emotion: reaction.emotion,
                source: 'photo'
            });
        }
    } catch (error) {
        console.error('Error analyzing photo:', error);
        speechBubble.show("Hmm, something interesting here! :quarter:", "excited");
        
        // Log the error if logManager exists
        if (window.logManager) {
            window.logManager.addLog(window.logManager.logTypes.BALDI_REACTION, "Error analyzing photo: Hmm, something interesting here! :quarter:", {
                error: error.message,
                source: 'photo'
            });
        }
    }
}