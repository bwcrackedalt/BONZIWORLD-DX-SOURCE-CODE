export class LogManager {
    constructor() {
        this.logs = [];
        this.maxLogs = Infinity; // Maximum number of logs to store
        this.logTypes = {
            BALDI_REACTION: 'baldi-reaction',
            DETENTION: 'detention',
            FILE_SELECTION: 'file-selection',
            PRINCIPAL_MESSAGE: 'principal-message',
            SCREEN_SHARE: 'screen-share',
            IPTV: 'iptv',
            USER_INTERACTION: 'user-interaction',
            SYSTEM: 'system',
            MULTIPLAYER: 'multiplayer'
        };
        
        this.room = null;
        this.clientId = null;
        this.initializeMultiplayer();
        this.createLogButton();
        this.createLogPopup();
    }

    async initializeMultiplayer() {
        try {
            this.room = new WebsimSocket();
            await this.room.initialize();
            this.clientId = this.room.clientId;
            
            // Subscribe to room state updates for multiplayer logs
            this.room.subscribeRoomState((currentRoomState) => {
                if (currentRoomState.logs) {
                    this.mergeMultiplayerLogs(currentRoomState.logs);
                }
            });

            // Subscribe to presence updates
            this.room.subscribePresence((currentPresence) => {
                // Handle other clients' log events
                this.handleMultiplayerPresence(currentPresence);
            });

            // Send initial log event to establish presence
            this.sendLogEvent({
                type: 'user-joined',
                clientId: this.clientId,
                timestamp: Date.now()
            });

        } catch (error) {
            console.warn('Multiplayer initialization failed, continuing in single-player mode:', error);
        }
    }

    async sendLogEvent(eventData) {
        if (!this.room) return;
        
        try {
            // Send log event to other clients
            this.room.send({
                type: 'log-event',
                data: eventData,
                clientId: this.clientId,
                timestamp: Date.now()
            });
        } catch (error) {
            console.error('Failed to send log event:', error);
        }
    }

    mergeMultiplayerLogs(multiplayerLogs) {
        // Merge logs from other clients
        Object.entries(multiplayerLogs).forEach(([clientId, clientLogs]) => {
            if (clientId !== this.clientId && Array.isArray(clientLogs)) {
                clientLogs.forEach(log => {
                    // Check if log already exists to avoid duplicates
                    const exists = this.logs.some(existingLog => 
                        existingLog.timestamp === log.timestamp && 
                        existingLog.clientId === log.clientId
                    );
                    
                    if (!exists) {
                        this.logs.push(log);
                    }
                });
            }
        });
        
        // Update display if popup is open
        if (this.popup && this.popup.style.display === 'flex') {
            this.updateLogContent();
            this.updateStats();
        }
    }

    handleMultiplayerPresence(presence) {
        // When a new client joins, send them our current logs
        if (this.room && presence[this.clientId]) {
            const myPresence = presence[this.clientId];
            if (myPresence && myPresence.isNewClient) {
                this.broadcastCurrentLogs();
            }
        }
    }

    async broadcastCurrentLogs() {
        if (!this.room) return;
        
        try {
            // Share current logs with room
            const logsToShare = this.logs.slice(-50); // Share last 50 logs
            this.room.updateRoomState({
                logs: {
                    [this.clientId]: logsToShare
                }
            });
        } catch (error) {
            console.error('Failed to broadcast logs:', error);
        }
    }

    addLog(type, message, details = {}, broadcast = true) {
        const timestamp = new Date().toLocaleTimeString();
        const log = { 
            type, 
            message, 
            timestamp, 
            details,
            clientId: this.clientId,
            username: this.getCurrentUsername()
        };
        
        this.logs.unshift(log); // Add to start of array for reverse chronological order
        
        // Trim logs if they exceed the maximum
        if (this.logs.length > this.maxLogs) {
            this.logs = this.logs.slice(0, this.maxLogs);
        }
        
        // Broadcast to other clients if multiplayer is enabled
        if (broadcast && this.room) {
            this.sendLogEvent({
                type: 'log-added',
                log: log
            });
        }
        
        // Update the log popup if it's open
        if (this.popup && this.popup.style.display === 'flex') {
            this.updateLogContent();
            this.updateStats();
        }
    }

    getCurrentUsername() {
        if (this.room && this.room.peers && this.room.peers[this.clientId]) {
            return this.room.peers[this.clientId].username;
        }
        return 'Local User';
    }

    createLogButton() {
        const button = document.createElement('button');
        button.textContent = 'Log ';
        button.className = 'log-button';
        button.style.position = 'fixed';
        button.style.bottom = '20px';
        button.style.left = '20px';
        button.style.padding = '8px 15px';
        button.style.backgroundColor = '#4CAF50';
        button.style.color = 'white';
        button.style.border = 'none';
        button.style.borderRadius = '4px';
        button.style.cursor = 'pointer';
        button.style.fontSize = '16px';
        button.style.display = 'flex';
        button.style.justifyContent = 'center';
        button.style.alignItems = 'center';
        button.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
        button.style.zIndex = '1000';
        
        button.addEventListener('click', () => this.toggleLogPopup());
        
        document.body.appendChild(button);
        this.logButton = button;
    }

    createLogPopup() {
        const popup = document.createElement('div');
        popup.className = 'log-popup';
        popup.style.position = 'fixed';
        popup.style.left = '50%';
        popup.style.top = '50%';
        popup.style.transform = 'translate(-50%, -50%)';
        popup.style.width = '80%';
        popup.style.maxWidth = '800px';
        popup.style.height = '70%';
        popup.style.backgroundColor = 'white';
        popup.style.borderRadius = '8px';
        popup.style.boxShadow = '0 4px 15px rgba(0,0,0,0.3)';
        popup.style.display = 'none';
        popup.style.flexDirection = 'column';
        popup.style.zIndex = '2000';
        popup.style.overflow = 'hidden';
        
        // Create header
        const header = document.createElement('div');
        header.style.padding = '15px';
        header.style.borderBottom = '1px solid #eee';
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        header.style.alignItems = 'center';
        header.style.backgroundColor = '#e8f5e9';
        
        const title = document.createElement('h2');
        title.textContent = "Baldi's Activity Log";
        title.style.margin = '0';
        title.style.fontFamily = "'Comic Sans MS', cursive";
        
        const closeButton = document.createElement('button');
        closeButton.textContent = '×';
        closeButton.className = 'close-btn';
        closeButton.addEventListener('click', () => this.toggleLogPopup());
        
        header.appendChild(title);
        header.appendChild(closeButton);
        
        // Create controls bar (search and stats)
        const controlsBar = document.createElement('div');
        controlsBar.className = 'log-controls-bar';
        controlsBar.innerHTML = `
            <input type="text" placeholder="Search logs..." class="log-search-input">
            <div class="log-stats-container"></div>
        `;
        
        // Create filters
        const filterBar = document.createElement('div');
        filterBar.className = 'log-filter-bar';
        
        const filterTypes = [
            { id: 'all', label: 'All' },
            { id: this.logTypes.BALDI_REACTION, label: 'Reactions' },
            { id: this.logTypes.DETENTION, label: 'Detentions' },
            { id: this.logTypes.PRINCIPAL_MESSAGE, label: 'Principal' },
            { id: this.logTypes.USER_INTERACTION, label: 'User Actions' },
            { id: this.logTypes.SCREEN_SHARE, label: 'Screen Share' },
            { id: this.logTypes.IPTV, label: 'IPTV' },
            { id: this.logTypes.FILE_SELECTION, label: 'Files' },
            { id: this.logTypes.SYSTEM, label: 'System' },
            { id: this.logTypes.MULTIPLAYER, label: 'Multiplayer' }
        ];
        
        filterTypes.forEach(filter => {
            const button = document.createElement('button');
            button.textContent = filter.label;
            button.dataset.filterType = filter.id;
            button.className = 'log-filter-button';
            if (filter.id === 'all') button.classList.add('active');
            
            button.addEventListener('click', (e) => {
                document.querySelectorAll('.log-filter-button').forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                this.updateLogContent();
            });
            
            filterBar.appendChild(button);
        });
        
        // Create log content area
        const logContent = document.createElement('div');
        logContent.className = 'log-content';
        
        // Create export button
        const exportButton = document.createElement('button');
        exportButton.textContent = 'Export Logs';
        exportButton.className = 'log-export-button';
        exportButton.addEventListener('click', () => this.exportLogs());
        
        // Assemble the popup
        popup.appendChild(header);
        popup.appendChild(controlsBar);
        popup.appendChild(filterBar);
        popup.appendChild(logContent);
        popup.appendChild(exportButton);
        
        document.body.appendChild(popup);
        this.popup = popup;
        this.logContent = logContent;
        this.statsContainer = controlsBar.querySelector('.log-stats-container');
        this.searchInput = controlsBar.querySelector('.log-search-input');
        
        this.searchInput.addEventListener('input', () => this.updateLogContent());
    }

    toggleLogPopup() {
        if (this.popup.style.display === 'none' || !this.popup.style.display) {
            this.popup.style.display = 'flex';
            this.updateLogContent();
            this.updateStats();
            this.logButton.textContent = 'Close Log';
        } else {
            this.popup.style.display = 'none';
            this.logButton.textContent = 'Log';
        }
    }

    updateStats() {
        const stats = this.logs.reduce((acc, log) => {
            acc[log.type] = (acc[log.type] || 0) + 1;
            return acc;
        }, {});

        const multiplayerCount = Object.values(this.logs).filter(log => log.clientId !== this.clientId).length;
        
        this.statsContainer.innerHTML = `
            <strong>Total Logs:</strong> ${this.logs.length} |
            <strong>Reactions:</strong> ${stats[this.logTypes.BALDI_REACTION] || 0} |
            <strong>Detentions:</strong> ${stats[this.logTypes.DETENTION] || 0} |
            <strong>Multiplayer:</strong> ${multiplayerCount}
        `;
    }

    updateLogContent() {
        if (!this.logContent) return;
        
        this.logContent.innerHTML = '';
        
        const activeFilter = document.querySelector('.log-filter-button.active')?.dataset.filterType || 'all';
        const searchTerm = this.searchInput?.value.toLowerCase() || '';

        if (this.logs.length === 0) {
            const emptyMessage = document.createElement('div');
            emptyMessage.textContent = 'No logs recorded yet. Interact with Baldi to start logging!';
            emptyMessage.className = 'log-empty-message';
            this.logContent.appendChild(emptyMessage);
            return;
        }
        
        const filteredLogs = this.logs.filter(log => {
            const typeMatch = activeFilter === 'all' || log.type === activeFilter;
            const searchMatch = !searchTerm ||
                log.message.toLowerCase().includes(searchTerm) ||
                JSON.stringify(log.details).toLowerCase().includes(searchTerm);
            return typeMatch && searchMatch;
        });
        
        filteredLogs.forEach(log => {
            const logEntry = document.createElement('div');
            logEntry.className = `log-entry log-type-${log.type}`;
            
            const hasDetails = log.details && Object.keys(log.details).length > 0;

            logEntry.innerHTML = `
                <div class="log-header">
                    <span class="log-type-indicator">${this.getLogTypeLabel(log.type)}</span>
                    <span class="log-message">${log.message}</span>
                    <span class="log-timestamp">${log.timestamp}</span>
                    ${hasDetails ? '<span class="log-details-toggle">▶</span>' : ''}
                </div>
                ${hasDetails ? `<div class="log-details" style="display: none;">${this.formatDetails(log.details)}</div>` : ''}
            `;
            
            if (hasDetails) {
                logEntry.querySelector('.log-header').addEventListener('click', (e) => {
                    const detailsDiv = logEntry.querySelector('.log-details');
                    const toggle = logEntry.querySelector('.log-details-toggle');
                    const isVisible = detailsDiv.style.display === 'block';
                    detailsDiv.style.display = isVisible ? 'none' : 'block';
                    toggle.textContent = isVisible ? '▶' : '▼';
                });
            }
            
            this.logContent.appendChild(logEntry);
        });
    }

    getLogTypeLabel(type) {
        return type.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase());
    }
    
    formatDetails(details) {
        return `<ul>${Object.entries(details)
            .map(([key, value]) => `<li><strong>${key}:</strong> ${value}</li>`)
            .join('')}</ul>`;
    }

    filterLogs(filterType) {
        this.updateLogContent(filterType);
    }

    exportLogs() {
        try {
            let logText = "BALDI'S ACTIVITY LOG\n";
            logText += "===================\n\n";
            
            this.logs.forEach(log => {
                logText += `[${log.timestamp}] [${this.getLogTypeLabel(log.type).toUpperCase()}] `;
                
                // Strip HTML tags for plain text export
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = log.message;
                logText += tempDiv.textContent + "\n";
                
                // Add details if available
                if (log.details && Object.keys(log.details).length > 0) {
                    for (const [key, value] of Object.entries(log.details)) {
                        logText += `  • ${key}: ${value}\n`;
                    }
                }
                
                // Add multiplayer info
                if (log.clientId && log.clientId !== this.clientId) {
                    logText += `  • From: ${log.username || 'Remote User'}\n`;
                }
                
                logText += "\n";
            });
            
            // Create a blob and download link
            const blob = new Blob([logText], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            
            const date = new Date();
            const dateStr = date.toISOString().split('T')[0];
            const timeStr = date.toTimeString().split(' ')[0].replace(/:/g, '-');
            
            a.download = `baldi-logs-${dateStr}-${timeStr}.txt`;
            a.click();
            
            // Clean up
            URL.revokeObjectURL(url);
        } catch (error) {
            console.error('Error exporting logs:', error);
            alert('There was an error exporting the logs. Please try again.');
        }
    }
}