import { captureAndAnalyzeFrame } from './reactions.js';

export class IPTVPlayer {
    constructor(chatUI) {
        this.chatUI = chatUI;
        this.video = document.getElementById('videoPlayer');
        this.urlInput = document.getElementById('iptvUrl');
        this.loadButton = document.getElementById('loadIptvStream');
        this.hls = null;
        this.frameCapture = null;
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.loadButton.addEventListener('click', () => {
            const url = this.urlInput.value.trim();
            if (url) {
                this.loadStream(url);
            } else {
                alert('Please enter an IPTV stream URL.');
            }
        });
    }

    loadStream(url) {
        // Destroy previous instance if it exists
        this.destroy();

        if (window.logManager) {
            window.logManager.addLog('iptv', `Attempting to load IPTV stream.`, { url });
        }

        if (Hls.isSupported()) {
            this.hls = new Hls();
            this.hls.loadSource(url);
            this.hls.attachMedia(this.video);
            this.hls.on(Hls.Events.MANIFEST_PARSED, async () => {
                try {
                    await this.video.play();
                    const speechBubble = window.speechBubble; // Access global speechBubble
                    if(speechBubble) {
                         speechBubble.show("Watching some TV! How exciting! :happy:", "happy");
                    }
                    if (this.chatUI) {
                        this.chatUI.addMessage('System', `Baldi is watching TV! 📺`);
                    }
                    if (window.logManager) {
                        window.logManager.addLog('iptv', 'IPTV stream loaded and playing.', { url });
                    }
                    this.startFrameCapture();
                } catch (error) {
                    if (error.name !== 'AbortError') {
                        console.error('Error playing IPTV stream:', error);
                    }
                }
            });
            this.hls.on(Hls.Events.ERROR, (event, data) => {
                 if (data.fatal) {
                    console.error('Fatal HLS error:', data);
                    const speechBubble = window.speechBubble;
                     if(speechBubble) {
                         speechBubble.show("Oh no! This TV channel isn't working! :sad:", "sad");
                    }
                    if (this.chatUI) {
                        this.chatUI.addMessage('System', `This TV channel isn't working! 😭`);
                    }
                    if (window.logManager) {
                       window.logManager.addLog('iptv', 'Failed to load IPTV stream.', { url, error: data.details, type: 'hls.js error' });
                    }
                 }
            });
        } else if (this.video.canPlayType('application/vnd.apple.mpegurl')) {
            // Native HLS support on platforms like Safari
            this.video.src = url;
            this.video.addEventListener('loadedmetadata', async () => {
                try {
                    await this.video.play();
                    const speechBubble = window.speechBubble;
                    if(speechBubble) {
                         speechBubble.show("Watching some TV! How exciting! :happy:", "happy");
                    }
                     if (this.chatUI) {
                        this.chatUI.addMessage('System', `Baldi is watching TV! 📺`);
                    }
                    if (window.logManager) {
                        window.logManager.addLog('iptv', 'IPTV stream loaded and playing (native HLS).', { url });
                    }
                    this.startFrameCapture();
                } catch (error) {
                     if (error.name !== 'AbortError') {
                        console.error('Error playing IPTV stream:', error);
                    }
                }
            });
        } else {
            alert('Your browser does not support HLS playback.');
             const speechBubble = window.speechBubble;
             if(speechBubble) {
                 speechBubble.show("My TV is broken! I can't watch this. :angry:", "angry");
            }
            if (window.logManager) {
                window.logManager.addLog('iptv', 'HLS playback not supported by this browser.', { url, error: 'HLS not supported' });
            }
        }
    }

    startFrameCapture() {
        this.stopFrameCapture(); // Clear any existing interval
        this.frameCapture = setInterval(() => {
            if (this.video && !this.video.paused && this.video.src) {
                captureAndAnalyzeFrame(this.video);
            }
        }, 5000); // Analyze frame every 5 seconds
    }

    stopFrameCapture() {
        if (this.frameCapture) {
            clearInterval(this.frameCapture);
            this.frameCapture = null;
        }
    }

    destroy() {
        const wasPlaying = !!this.hls;
        const currentUrl = this.urlInput.value.trim();
        if (this.hls) {
            this.hls.destroy();
            this.hls = null;
        }
        this.stopFrameCapture();
        this.video.src = '';
        if (wasPlaying && this.chatUI) {
            this.chatUI.addMessage('System', 'TV time is over!');
            if (window.logManager) {
                window.logManager.addLog('iptv', `IPTV stream stopped.`, { url: currentUrl });
            }
        }
    }
}