export class BannerManager {
    constructor() {
        this.createDiscordBanner();
    }

    createDiscordBanner() {
        const banner = document.createElement('div');
        banner.className = 'discord-banner';
        banner.innerHTML = 'Join the discord today! <a href="https://discord.gg/356ktJUGPx" target="_blank">https://discord.gg/356ktJUGPx</a>';
        banner.style.backgroundColor = '#5865F2';
        banner.style.color = 'white';
        banner.style.padding = '10px';
        banner.style.textAlign = 'center';
        banner.style.fontWeight = 'bold';
        banner.style.width = '100%';
        banner.style.position = 'fixed';
        banner.style.top = '0';
        banner.style.left = '0';
        banner.style.zIndex = '2000';
        banner.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';

        document.body.appendChild(banner);
        
        // Add some padding to body to account for banner
        document.body.style.paddingTop = '40px';
        
        // Adjust baldi section position
        const baldiSection = document.querySelector('.baldi-section');
        if (baldiSection) {
            baldiSection.style.top = '60px';
        }
    }
}